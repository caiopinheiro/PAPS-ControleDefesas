<?php
$user =& JFactory::getUser();
if(!$user->username) die( 'Acesso Restrito.' );


// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
jimport('joomla.application.component.view');
 
/**
 * HTML View class for the HelloWorld Component
 */
class DefesasCoordenadorViewListaBancas extends JViewLegacy
{
        // Overwriting JView display method
        function display($tpl = null) 
        {
                // Assign data to the view
//                $this->msg = 'Lista de Bancas Para Avaliar';
                //$this->msg = $this->get('Msg');       

                $this->bancas = $this->get('Banca');	
				//$model = $this->getModel();
				//$this->bancas = $model->getBanca();

                //$model = $this->getModel();
				// use the model to get the data we want to use on the frontend tmpl
				//$data = $model->getBanca($nome,$status_bancas);
				// assign model results to view tmpl
				//$this->assignRef( 'data', $data );    
                
                // Display the view
                parent::display($tpl);
        }
        
}
