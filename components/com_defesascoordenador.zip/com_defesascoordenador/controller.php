<?php

/**
 * @version     1.0.0
 * @package     com_defesascoordenador
 * @copyright   Copyright (C) 2014. Todos os direitos reservados.
 * @license     GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 * @author      Caio <pinheiro.caiof@gmail.com> - http://
 */
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

class DefesascoordenadorController extends JController {

    /**
     * Method to display a view.
     *
     * @param	boolean			$cachable	If true, the view output will be cached
     * @param	array			$urlparams	An array of safe url parameters and their variable types, for valid values see {@link JFilterInput::clean()}.
     *
     * @return	JController		This object to support chaining.
     * @since	1.5
     */
    public function display($cachable = false, $urlparams = false) {
        require_once JPATH_COMPONENT . '/helpers/defesascoordenador.php';
		
	//	$nome_orientador = JRequest::getCmd('buscaNomeOrientador', false);
		//$status_bancas = JRequest::getCmd('buscaStatusBanca', false);
		
		
	
	//	$model = $this->getModel();
	//	$this->bancas = $model->getBanca($nome_orientador, $status_bancas);
		
        parent::display($cachable, $urlparams);
			
        return $this;
    }
    
    function shout(){
		echo '<p>'.$this->msg.'</p>';
		return var_dump($this->get('Banca'));
	}

	function banca(){
		$nome_orientador = JRequest::getCmd('buscaNomeOrientador', false);
		$status_bancas = JRequest::getCmd('buscaStatusBanca', false);
//		echo '<p>'.$nome_orientador.'nomeorientador_testecontroller</p>';
//		echo '<p>'.$status_bancas.'statusBanca_testecontroller</p>'; 
		
//		getBanca($nome_orientador, $status_bancas);
		
//		header('Location: index.php?option=com_defesasorientador&view=listabancas');
	}
	
	
}
