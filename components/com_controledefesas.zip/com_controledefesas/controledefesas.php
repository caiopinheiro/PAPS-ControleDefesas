<?php
/**
 * @version     1.0.0
 * @package     com_controledefesas
 * @copyright   Copyright (C) 2014. Todos os direitos reservados.
 * @license     GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 * @author      Caio <pinheiro.caiof@gmail.com> - http://
 */

defined('_JEXEC') or die;

// Include dependancies
jimport('joomla.application.component.controller');

// Execute the task.
$controller	= JController::getInstance('Controledefesas');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
