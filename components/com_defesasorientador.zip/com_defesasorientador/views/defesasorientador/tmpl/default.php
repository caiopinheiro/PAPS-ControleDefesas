<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

//$document = &JFactory::getDocument();
//$document->addScript("includes/js/joomla.javascript.js");

//include_once("components/com_portalsecretaria/portalsecretaria.html.php");
?>
<h1><?php echo $this->msg; ?></h1>


